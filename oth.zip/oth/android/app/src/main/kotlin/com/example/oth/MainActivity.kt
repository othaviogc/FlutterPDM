package com.example.oth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
